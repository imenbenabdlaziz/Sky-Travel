#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>





void
on_ajouterh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_retourh_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_supprimerh_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierh_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_validerh_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);






void
on_refresh1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnexiontaha_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_reclamationtaha_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
