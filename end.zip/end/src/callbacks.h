#include <gtk/gtk.h>


void
on_button1n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonreclamationimen_clicked       (GtkButton       *button,
                                        gpointer         user_data);
